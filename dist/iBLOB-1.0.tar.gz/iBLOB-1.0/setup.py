from setuptools import setup

setup(name='iBLOB',
      version='1.0',
      description='Convert any file to/from binary format',
      author='Eden Dadon',
      packages=['iBLOB'],
      zip_safe=False)
